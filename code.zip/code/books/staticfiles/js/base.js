// static/js/base.js

console.log('JavaScript Here!')